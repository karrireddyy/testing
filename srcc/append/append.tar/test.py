original = "/tmp/test/some_0.hocr"
corrected = "/tmp/test/correct.html"

first = open("/opt/first.txt").read()
open(corrected, "w").write(first + open(original).read())

last = open("/opt/last.txt").read()
f = open(corrected, 'a')
f.write(last)
f.close()
