python /app/laterhocr/pdf2jpg.py

./app/laterhocr/hocr-pdf  /tmp/test2/ . > "/tmp/test2/some_0.pdf"