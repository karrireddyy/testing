python pdf2jpg.py $1

python jpg2hocr.py

hocr-pdf  /tmp/test/ . > "/tmp/test/some_0.pdf"